$('.btn-finish-purchase').on('click', function(){
    $(".close-command").submit();
});