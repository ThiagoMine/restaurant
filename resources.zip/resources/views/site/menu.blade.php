@extends("site.layouts.app")

@section('title', "Felipe Peretta - Cardapio")

@section("content")
	@include("site.layouts.partials.menu.banner")
	@include("site.layouts.partials.menu.accordion")	
@endsection