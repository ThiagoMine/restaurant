<div class="container">
	<div class="top-footer">
		<div class="row">
			<div class="col-md-8">
				<div class="subscribe-form">
					<div class="head">Faça seu pedido conosco!!!</div><br><br>
					<div class="text">
						WhatsApp: (12) 99725-8617
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="social-bottom">
					<span>Nos siga:</span>
					<ul>
						<li><a href="#" class="fa fa-facebook"></a></li>
						<li><a href="#" class="fa fa-twitter"></a></li>
						<li><a href="#" class="fa fa-rss"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	{{-- <div class="bottom-footer">
		<p>
			<span>Copyright © 2084 <a href="#">Your Company Name</a> 
			| Design: <a rel="nofollow" href="http://www.templatemo.com" target="_parent"><span class="blue">template</span><span class="green">mo</span></a></span>
		</p>
	</div> --}}
	
</div>