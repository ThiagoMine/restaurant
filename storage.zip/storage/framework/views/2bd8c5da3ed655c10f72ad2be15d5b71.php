<?php $__env->startSection('title', "Registro de Produtos"); ?>

<?php $__env->startSection("content"); ?>
	<div id="content-wrapper" class="d-flex flex-column">

		<!-- Main Content -->
		<div id="content">

			<!-- Topbar -->
			<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow d-flex
				justify-content-between">
				<!-- Page Heading -->
				<h1 class="h3 mb-4 text-gray-800">Produtos</h1>

				<div>
					<a href="/admin/register/products/create" class="btn btn-lg btn-success mx-2 mb-3">
						<span>Novo Produto</span>
					</a>
				</div>
			</nav>
			<!-- End of Topbar -->

			<!-- Begin Page Content -->
			<div class="container-fluid">

				<!-- DataTales Example -->
				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Produtos Cadastros</h6>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>Foto</th>
										<th>Nome</th>
										<th>Valor</th>
										<th>Está Ativo</th>
										<th>Ações</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>Foto</th>
										<th>Nome</th>
										<th>Valor</th>
										<th>Está Ativo</th>
										<th>Ações</th>
									</tr>
								</tfoot>
								<tbody>
									<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<?php if($product->type != 1): ?>
											<?php continue; ?>;
										<?php endif; ?>
										<?php
											$image = asset('/storage/'.$product->image);
										?>
										<tr>
											<td>
												<div class="mw-150px">
													<img 
														src="<?php echo e($image); ?>" 
														alt="<?php echo e($product->seo_name); ?>" class="img-fluid">
												</div>
											</td>
											<td><?php echo e($product->name); ?></td>
											<td>R$ <?php echo e($product->price); ?></td>
											<td>
												<?php if($product->is_active): ?>
													Sim
												<?php else: ?>
													Não
												<?php endif; ?>
											</td>
											<td>
												<div class="align-items-center row no-gutters">
													<a href="<?php echo e(route("products.edit", $product)); ?>" class="btn btn-warning btn-circle ml-3 img-fluid">
														<i class="fas fa-pen"></i>
													</a>

													<form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST">
														<?php echo method_field("DELETE"); ?>
														<?php echo csrf_field(); ?>
														<button class="btn btn-danger btn-circle ml-3">
															<i class="fas fa-trash"></i>
														</button>
													</form>
												</div>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
			</div>
			<!-- /.container-fluid -->

		</div>
		<!-- End of Main Content -->

		<!-- Footer -->
		<footer class="sticky-footer bg-white">
			<div class="container my-auto">
				<div class="copyright text-center my-auto">
					<span>Copyright &copy; Your Website 2020</span>
				</div>
			</div>
		</footer>
		<!-- End of Footer -->

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/system/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/system/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/system/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/products/list-products.blade.php ENDPATH**/ ?>