<div id="testimonails">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading-section">
					<h2>O que nossos clientes dizem!!!</h2>
					<img src="<?php echo e(asset('images/site/under-heading')); ?>.png" alt="" >
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="testimonails-slider">
				  <ul class="slides">
					<li>
						<div class="testimonails-content">
							<p>A melhor pizza que eu já comi!!! Muito bom...</p>
							<h6>Thiago - <a href="#">Natividade da Serra</a></h6>
						</div>
					</li>
					<li>
						<div class="testimonails-content">
							<p>Lanche maravilhoso, com materiais de qualidade, muito bom!!!!</p>
							<h6>Gabriela - <a href="#">Natividade da Serra</a></h6>
						</div> 
					</li>
				  </ul>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/layouts/partials/home/testimonials.blade.php ENDPATH**/ ?>