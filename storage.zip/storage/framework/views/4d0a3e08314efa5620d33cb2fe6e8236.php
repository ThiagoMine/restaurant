<div class="container">
	<div class="top-footer">
		<div class="row">
			<div class="col-md-8">
				<div class="subscribe-form">
					<div class="head">Faça seu pedido conosco!!!</div><br><br>
					<div class="text">
						WhatsApp: (12) 99725-8617
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="social-bottom">
					<span>Nos siga:</span>
					<ul>
						<li><a href="#" class="fa fa-facebook"></a></li>
						<li><a href="#" class="fa fa-twitter"></a></li>
						<li><a href="#" class="fa fa-rss"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	
	
</div><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/layouts/partials/footer.blade.php ENDPATH**/ ?>