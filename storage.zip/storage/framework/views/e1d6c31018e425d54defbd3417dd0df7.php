<?php $__env->startSection('title', "Login"); ?>

<?php $__env->startSection("content"); ?>

    <form method="POST" action="<?php echo e(route('login')); ?>" class="login-form">
        <div>
            <?php echo csrf_field(); ?>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <br>
            <label for="password">Senha:</label>
            <input type="password" name="password" id="password" required>
            <br>

            <div>
                <button type="submit" class="btn btn-primary btn-icon-split btn-lg">
                    <span class="icon text-white-50">
                        <i class="fas fa-flag"></i>
                    </span>
                    <span class="text">login</span>
                </button>
            </div>
        </div>
    </form>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/login.blade.php ENDPATH**/ ?>