<?php $__env->startSection('title', "Registro de Produtos"); ?>

<?php $__env->startSection("content"); ?>
<div id="content-wrapper" class="d-flex flex-column">

	

	<!-- Main Content -->
	<div id="content">

		<!-- Topbar -->
		<nav class="navbar navbar-expand navbar-light bg-white topbar d-flex justify-content-between mb-4 static-top shadow">
			<h1 class="h3 mb-4 text-gray-800">Comanda <?php echo e($command_number); ?></h1>
			<a href="/admin/sales-control" class="btn btn-lg btn-primary mx-2 mb-3">
				<span>Voltar para vendas</span>
			</a>
			<a href="/admin" class="btn btn-lg btn-primary mx-2 mb-3">
				<i class="fa fa-home"></i>
			</a>
			
		</nav>
		<!-- End of Topbar -->

		<!-- Begin Page Content -->
		<div class="container-fluid row">
			<!-- Orders -->
			<div class="col-lg-9 mb-4">

				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Pedidos</h6>
					</div>
					<div class="card-body">
						<div class="filipeta p-3">
							
							
							<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="order">
									<div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
										<span class="number text-gray-900">Pedido <?php echo e($order["id"]); ?></span>
										<span class="date text-gray-900"><?php echo e($order["created_at"]); ?></span>
									</div>
								
									<a class="btn btn-sm btn-danger btn-icon-split mb-3" href="#" data-toggle="modal" data-target="#cancelOrder">
										<span class="icon text-white-50">
											<i class="fas fa-times"></i>
										</span>
										<span class="text">Cancelar Pedido</span>
									</a>
								
									<h6>Items</h6>

									<?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="product">
											<div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
												<div>
													<span class="name text-gray-900 fs-15em"><?php echo e($product["name"]); ?></span>
												</div>
												<span class="value text-gray-900 fs-15em">R$ <?php echo e(number_format($product["value"], 2, ",", ".")); ?></span>
											</div>
											<?php if(isset($product['additionals'])): ?>
												<?php $__currentLoopData = $product['additionals']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="aditionals">
														<div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
															<div>
																<span class="name text-gray-900"><?php echo e($additional["name"]); ?></span>
															</div>
															<span class="value text-gray-900">R$ <?php echo e(number_format($additional["value"], 2, ",", ".")); ?></span>
														</div>  
													</div>	
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<hr class="sum">
									<div class="sub-total">
										<div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
											<span class="number text-blue-900 fs-15em">Total do Pedido</span>
											<span class="date text-blue-900 fs-15em">R$ <?php echo e(number_format($order["order_total"], 2, ",", ".")); ?></span>
										</div>
									</div>
								</div>
								<hr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



							<div class="total">
								<div class="content w-100 d-flex justify-content-between flex-wrap mb-2 ">
									<span class="number text-blue-900 fs-12em">Taxa de Entrega</span>
									<span class="date text-blue-900 fs-12em">R$ <?php echo e(number_format($delivery_tax, 2, ",", ".")); ?></span>
								</div>
								<div class="content w-100 d-flex justify-content-between flex-wrap mb-2 ">
									<span class="number text-blue-900 fs-15em">Total Consumido na Comanda</span>
									<span class="date text-blue-900 fs-15em">R$ <?php echo e(number_format($sale_total_value, 2, ",", ".")); ?></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Actions -->
			<div class="col-lg-3 mb-4">

				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Ações</h6>
					</div>
					<div class="card-body">
						<div>
							<a href="<?php echo e(url()->to('/')); ?>/admin/order/create-order/<?php echo e($command_number); ?>" class="btn btn-lg btn-success mx-2 mb-3 w-100">
								<span>Pedido</span>
							</a>
						</div>
						
						<div>
							<button type="button" data-toggle="modal" data-target="#close_command" class="btn btn-lg btn-danger mx-2 mb-3 w-100">
								<span>Fechar</span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /.container-fluid -->

	</div>
	<!-- End of Main Content -->

	<!-- Footer -->
	<footer class="sticky-footer bg-white">
		<div class="container my-auto">
			<div class="copyright text-center my-auto">
				<span>Copyright &copy; Your Website 2020</span>
			</div>
		</div>
	</footer>
	<!-- End of Footer -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
	<div class="modal" id="close_command">
		<div class="modal-dialog mw-70 w-70">
			<div class="modal-content">
		
				<!-- Modal Header -->
				<div class="modal-header">
					<h4 class="modal-title">Fechar Comanda</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
		
				<!-- Modal body -->
				<div class="modal-body">
					<form action="/admin/sales-control/close-command" method="POST" class="close-command">
						<h5>Informe a forma de Pagamento</h5>
						<?php echo csrf_field(); ?>
						<input type="hidden" name="id" value="<?php echo e($id); ?>">
						<div class="form-group">
							<div class="form-check">
								<input class="form-check-input" type="radio" name="payment_form" id="payment-form-credit" value="credit" checked>
								<label class="form-check-label" for="payment-form-credit">
									Cartão de Crédito
								</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="radio" name="payment_form" id="payment-form-debit" value="debit">
								<label class="form-check-label" for="payment-form-debit">
									Cartão de Débito
								</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="radio" name="payment_form" id="payment-form-money" value="money">
								<label class="form-check-label" for="payment-form-money">
									Dinheiro
								</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="radio" name="payment_form" id="payment-form-pix" value="pix">
								<label class="form-check-label" for="payment-form-pix">
									Pix
								</label>
							</div>
						</div>

					</form>
				</div>
		
				<!-- Modal footer -->
				<div class="modal-footer">
					<button type="button" class="btn btn-success btn-finish-purchase">Finalizar Comanda</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
				</div>
	
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
	<script src="<?php echo e(asset('js/system/view-command.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/sales-control/view-command.blade.php ENDPATH**/ ?>