<div id="slider">
	<div class="flexslider">
	  <ul class="slides">
		<li>
			<!-- <div class="slider-caption">
				<h1>Delicious Meals</h1>
				<p>Donec justo dui, semper vitae aliquam euzali, ornare pretium enim. Maecenas molestie diam
				<br><br>eget tellus luctus fermentum.</p>
				<a href="single-post.html">Shop Now</a>
			</div> -->
		  <img src="<?php echo e(asset('images/site/slide1.png')); ?>" alt="" />
		</li>
		<!-- <li>
			<div class="slider-caption">
				<h1>Ice-cream Menus</h1>
				<p>Nulla id iaculis ligula. Vivamus mattis quam eget urna tincidunt consequat. Nullam 
				<br><br>consectetur tempor neque vitae iaculis. Aliquam erat volutpat.</p>
				<a href="single-post.html">More Details</a>
			</div>
		  <img src="<?php echo e(asset('images/site/slide2.jpg')); ?>" alt="" />
		</li>
		<li>
			<div class="slider-caption">
				<h1>Healthy Drinks</h1>
				<p>Maecenas fermentum est ut elementum vulputate. Ut vel consequat urna. Ut aliquet 
				<br><br>ornare massa, quis dapibus quam condimentum id.</p>
				<a href="single-post.html">Get Ready</a>
			</div>
		  <img src="<?php echo e(asset('images/site/slide3.jpg')); ?>" alt="" />
		</li> -->
	  </ul>
	</div>
</div><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/layouts/partials/home/slidebanners.blade.php ENDPATH**/ ?>