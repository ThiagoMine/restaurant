<div id="menu-accordion" class="">
	<div class="container">
		<div class="row">
            <div class="accordion" id="accordionExample">
                <?php if(isset($categories)): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="category_<?php echo e($category['id']); ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#category_<?php echo e($category['id']); ?>" aria-expanded="true" aria-controls="category_<?php echo e($category['id']); ?>">
                                    <?php echo e($category['name']); ?>

                                </button>
                            </h2>
                            <div id="category_<?php echo e($category['id']); ?>" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <?php if(isset($category['products'])): ?>
                                    <div class="row">
                                        <?php $__currentLoopData = $category['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card col-lg-4 col-sm-6">
                                                <div class="image">
                                                    <img src="<?php echo e(asset($product['image'])); ?>" alt="" class="img-80">
                                                    
                                                </div>
                                                <div class="title">
                                                    <?php echo e($product['name']); ?>

                                                </div>
                                                <div class="description">
                                                    <?php echo e($product['description']); ?>

                                                </div>
                                                <div class="price">
                                                    R$ <?php echo e(number_format($product['price'], 2, '.', ',')); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/layouts/partials/menu/accordion.blade.php ENDPATH**/ ?>