<div id="menu-banners" class="bg-gradient-dark">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading-section">
					<img src="<?php echo e(asset('images/site/menu')); ?>.png" alt="Banner do Cardapio" class="img-80">
				</div>
			</div>
		</div>
		
	</div>
</div><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/layouts/partials/menu/banner.blade.php ENDPATH**/ ?>