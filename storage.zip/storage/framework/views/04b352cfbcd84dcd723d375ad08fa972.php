<?php $__env->startSection('title', "Registro de Mesas"); ?>

<?php $__env->startSection("content"); ?>
	<div id="content-wrapper" class="d-flex flex-column">

		<!-- Main Content -->
		<div id="content">

			<!-- Topbar -->
			<nav class="navbar navbar-expand navbar-light bg-white topbar d-flex justify-content-between mb-4 static-top shadow">
				<h1 class="h3 mb-4 text-gray-800">Cadastro de Mesas</h1>
				<a href="/admin/register/tables" class="btn btn-lg btn-primary mx-2 mb-3">
					<span>Voltar para lista de mesas</span>
				</a>
			</nav>
			<!-- End of Topbar -->

			<!-- Begin Page Content -->
			<div class="container-fluid">
				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Registrar Mesas</h6>
					</div>
					<div class="card-body">
						<?php if(!$isEdit): ?>
							<form action="<?php echo e(route('tables.store')); ?>" enctype="multipart/form-data" method="POST">
								<?php echo csrf_field(); ?>
						<?php else: ?>
							<form action="<?php echo e(route('tables.update', $table)); ?>" enctype="multipart/form-data" method="POST">
								<?php echo method_field("PUT"); ?>
								<?php echo csrf_field(); ?>
						<?php endif; ?>
							<div class="form-group">
								<label for="number" class="fs-15em ">Número da Mesa:</label>
								<input type="text" class="form-control w-50" id="number" name="number" placeholder="Informe o número da Mesa"
									<?php if($isEdit): ?> value="<?php echo e($table->number); ?>" <?php endif; ?>>
							</div>

							<div class="mb-3 form-check form-check-lg">
								<input 
									type="checkbox" 
									class="form-check-input" 
									id="is_active" 
									name="is_active"
									<?php if($isEdit && $table->is_active): ?>
										<?php if(true): echo 'checked'; endif; ?>
									<?php endif; ?>
								>
								<label class="form-check-label fs-15em" for="is_active">Ativo</label>
							</div>

							<button type="submit" class="btn btn-primary mt-5">Salvar</button>
						</form>
					</div>
				</div>
			</div>
			<!-- /.container-fluid -->

		</div>
		<!-- End of Main Content -->

		<!-- Footer -->
		<footer class="sticky-footer bg-white">
			<div class="container my-auto">
				<div class="copyright text-center my-auto">
					<span>Copyright &copy; Your Website 2020</span>
				</div>
			</div>
		</footer>
		<!-- End of Footer -->

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/tables/create-tables.blade.php ENDPATH**/ ?>