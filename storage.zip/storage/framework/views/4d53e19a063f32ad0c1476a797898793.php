<?php $__env->startSection('title', "Felipe Peretta - Cardapio"); ?>

<?php $__env->startSection("content"); ?>
	<?php echo $__env->make("site.layouts.partials.menu.banner", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("site.layouts.partials.menu.accordion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("site.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/menu.blade.php ENDPATH**/ ?>