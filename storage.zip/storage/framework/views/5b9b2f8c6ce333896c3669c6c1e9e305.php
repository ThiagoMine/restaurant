<?php $__env->startSection('title', "Registro de Produtos"); ?>

<?php $__env->startSection("content"); ?>
	<div id="content-wrapper" class="d-flex flex-column">

		<!-- Main Content -->
		<div id="content">

			<!-- Topbar -->
			<nav class="navbar navbar-expand navbar-light bg-white topbar d-flex justify-content-between mb-4 static-top shadow">
				<h1 class="h3 mb-4 text-gray-800">Relatórios</h1>
				<a href="/admin" class="btn btn-lg btn-primary mx-2 mb-3">
					<span>Voltar para tela inicial</span>
				</a>
			</nav>
			<!-- End of Topbar -->

			<!-- Begin Page Content -->
			<div class="container-fluid">
				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Relatório de vendas:</h6>
					</div>
					<div class="card-body">
                        
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="purchase">
                                <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                    <span class="number text-gray-900 h4">Compra <?php echo e($item["purchaseId"]); ?></span>
                                    <span class="date text-gray-900"><?php echo e($item["created_at"]); ?></span>
                                </div>
                                <div class="sub-total">
                                    <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                        <span class="number text-blue-900 fs-15em">Total da Compra</span>
                                        <span class="date text-blue-900 fs-15em">R$ <?php echo e(number_format($item["total"], 2, ",", ".")); ?></span>
                                    </div>
                                </div>
                                <a class='show-more' data-purchaseid="<?php echo e($item["purchaseId"]); ?>">
                                    Demais informações
                                    <i class="fa fa-angle-right"></i>
                                </a>
                                <?php $__currentLoopData = $item['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($order['products'])): ?>
                                        <div class="orders hidden purchase-<?php echo e($item["purchaseId"]); ?>">
                                            <h5>Pedido <?php echo e($order['orderId']); ?> - Items</h5>

                                            <?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="product">
                                                    <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                                        <div>
                                                            <span class="name text-gray-900 fs-15em"><?php echo e($product["name"]); ?></span>
                                                        </div>
                                                        <span class="value text-gray-900 fs-15em">R$ <?php echo e(number_format($product["value"], 2, ",", ".")); ?></span>
                                                    </div>
                                                    <?php if(isset($product['additionals'])): ?>
                                                        <?php $__currentLoopData = $product['additionals']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="aditionals">
                                                                <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                                                    <div>
                                                                        <span class="name text-gray-900"><?php echo e($additional["name"]); ?></span>
                                                                    </div>
                                                                    <span class="value text-gray-900">R$ <?php echo e(number_format($additional["value"], 2, ",", ".")); ?></span>
                                                                </div>  
                                                            </div>	
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <hr class="sum">
                                            <div class="sub-total">
                                                <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                                    <span class="number text-blue-900 fs-15em">Total do Pedido</span>
                                                    <span class="date text-blue-900 fs-15em">R$ <?php echo e(number_format($order["orderTotal"], 2, ",", ".")); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="report-total">
                            <div class="content w-100 d-flex justify-content-between flex-wrap mb-2">
                                <span class="number text-blue-900 fs-15em">Total vendido no período: </span>
                                <span class="date text-blue-900 fs-15em">R$ <?php echo e(number_format($reportTotal, 2, ",", ".")); ?></span>
                            </div>
                        </div>
					</div>
				</div>
			</div>
			<!-- /.container-fluid -->

		</div>
		<!-- End of Main Content -->

		<!-- Footer -->
		<footer class="sticky-footer bg-white">
			<div class="container my-auto">
				<div class="copyright text-center my-auto">
					<span>Copyright &copy; Your Website 2020</span>
				</div>
			</div>
		</footer>
		<!-- End of Footer -->

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script>
        $(".show-more").on("click", function() {
            var purchaseId = $(this).data('purchaseid');
            if ($(".purchase-"+purchaseId).hasClass('hidden')) {
                $(".purchase-"+purchaseId).removeClass('hidden');
                $(this).find('i').css('transform', 'rotate(' + 90 + 'deg)');
            } else {
                $(".purchase-"+purchaseId).addClass('hidden');
                $(this).find('i').css('transform', 'rotate(' + -90 + 'deg)');
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/reports/filter-sales.blade.php ENDPATH**/ ?>