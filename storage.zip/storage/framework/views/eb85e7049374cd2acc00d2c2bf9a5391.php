<?php $__env->startSection('title', "Registrar Pedidos"); ?>

<?php $__env->startSection("content"); ?>
	<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav
                class="navbar navbar-expand navbar-light bg-white topbar d-flex justify-content-between mb-4 static-top shadow">
                <h1 class="h3 mb-4 text-gray-800">Gerar Pedido</h1>
                <div class="actions">
                    <a href="/admin/sales-control" class="btn btn-lg btn-primary mx-2 mb-3">
                        <span>Voltar para gestão de pedidos</span>
                    </a>
                    <a href="/admin" class="btn btn-lg btn-primary mx-2 mb-3">
                        <i class="fa fa-home"></i>
                    </a>
                </div>
            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid h-80 row">

                <!-- Page Heading -->
                <!-- Orders -->
                <div class="col-lg-9 mb-4 h-100">
                    <div class="card shadow mb-4 h-100">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Escolha seu produto</h6>
                        </div>
                        <div class="card-body bg-gradient-dark h-100">
                            <!-- Vertical Tabs -->
                            <div class="d-flex h-100 product-holder">	
                                <div class="w-30">
                                    <ul class="nav nav-tabs flex-column" id="myTab" role="tablist">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item">
                                                <a class="nav-link categories-tabs <?php if($loop->first): ?> active <?php endif; ?>" id="<?php echo e($category['seo_name']); ?>-tab" data-toggle="tab" href="#<?php echo e($category['seo_name']); ?>"
                                                    role="tab" aria-controls="<?php echo e($category['seo_name']); ?>" aria-selected="true"><?php echo e($category['name']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="w-70 h-100">
                                    <!-- Tab content -->
                                    <div class="ml-1 p-1 h-100 tab-content bg-gradient-light scroll-enable" id="myTabContent">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="<?php echo e($category['seo_name']); ?>" role="tabpanel"
                                                aria-labelledby="<?php echo e($category['seo_name']); ?>-tab">
                                                <h3 class="text-center"><?php echo e($category['name']); ?></h3>
                                                <div class="d-flex justify-content-around bg-transparent flex-wrap">
                                                    <?php if(isset($category['products']) && (count($category['products']) >0)): ?>

                                                        <?php $__currentLoopData = $category['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <!-- Product Item -->
                                                            <div class="product-item border border-secondary p-3 w-30 mt-5">
                                                                <div class="image-item">
                                                                    <img class="img-item" src="<?php echo e($product['image']); ?>" alt="<?php echo e($product['name']); ?>">
                                                                </div>
                                                                <div class="name text-gray-900 fs-15em"><?php echo e($product['name']); ?></div>
                                                                <div class="price text-gray-900">R$ <?php echo e(number_format($product['price'], 2, ",", ".")); ?></div>
                                                                <div class="action"> 
                                                                    
                                                                    <a class="btn btn-lg btn-success mx-2 addProductModal" href="#"
                                                                        data-productid="<?php echo e($product['id']); ?>" data-name="<?php echo e($product['name']); ?>" 
                                                                        data-category="<?php echo e($category['seo_name']); ?>">
                                                                        <span>adicionar</span>
                                                                    </a>					
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <h3> Nenhum Produto cadastrado</h3>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 mb-4">
                    <div class="card shadow mb-4">
                        <form action="<?php echo e(url()->to('/')); ?>/admin/order/create-order/1" method="POST" id="order-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="command" value="<?php echo e($command); ?>">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Pedido</h6>
                            </div>
                            <div class="card-body">
                                <div class="full-filipeta p-3">
                                    <div class="order">
                                        <div class="my-1">
                                            <span>Código:</span>
                                            <span class="text-gray-900">Xa1H#</span>
                                        </div>
                                        <h6>Items</h6>

                                        <div class="no-product">
                                            <span class="name text-gray-900 fs-15em">
                                                Nenhum produto adicionado ainda
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-5">
                                    <a class="btn btn-lg btn-success mx-2 finish-order">
                                        <span>Finalizar pedido e enviar para a cozinha</span>
                                    </a>                                    
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2020</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="addProductModal-<?php echo e($category['seo_name']); ?>">
            <div class="modal-dialog mw-70 w-70">
                <div class="modal-content">
            
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Informe as observações e os adicionais</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
            
                    <!-- Modal body -->
                    <div class="modal-body">
                        <form class="order-add-form">
                            <div class="obs form-group">
                                <h5>Informações Adicionais</h5>
                                <textarea class="form-control obs" name="obs" cols="60" rows="15"></textarea>
                            </div>
                            <hr>
                            <?php if(isset($category['additionals']) && (count($category['additionals']) >0)): ?>
                                <h5>Adicionais</h5>
                                <div class="aditionals d-flex flex-wrap">
                                <?php $__currentLoopData = $category['additionals']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group aditional-item w-30">
                                        <div class="form-check form-check-lg">
                                            <input type="checkbox" class="form-check-input" name="additionals" id="<?php echo e($additional['seo_name']); ?>" value="<?php echo e($additional['id']); ?> - <?php echo e($additional['name']); ?>">
                                            <label class="form-check-label" for="catupiry"><?php echo e($additional['name']); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <div class="hidden product-information">
                                
                            </div>
                        </form>
                    </div>
            
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success btn-add-product"
                            data-category="<?php echo e($category['seo_name']); ?>">Adicionar</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    </div>
        
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/system/create-order.js')); ?>"></script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make("system.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/system/order/create-order.blade.php ENDPATH**/ ?>