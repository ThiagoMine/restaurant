<?php $__env->startSection('title', "Felipe Peretta"); ?>

<?php $__env->startSection("content"); ?>
	<?php echo $__env->make("site.layouts.partials.home.slidebanners", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("site.layouts.partials.home.services", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("site.layouts.partials.home.latest", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make("site.layouts.partials.home.testimonials", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("site.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/thiagomine/Documentos/Projetos/restaurant/resources/views/site/index.blade.php ENDPATH**/ ?>